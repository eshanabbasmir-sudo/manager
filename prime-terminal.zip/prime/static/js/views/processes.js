/** Processes and listening ports, read straight from /proc. */
import { api } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc, bytes, timestamp, duration } from "../ui.js";

const state = {
  tab: "processes",
  items: [],
  filter: "",
  sort: "cpu",
  live: true,
  timer: null,
  ports: null,
  portsNote: "",
  ctx: null,
};

function procRows() {
  const needle = state.filter.toLowerCase();
  const items = state.items.filter(
    (p) => !needle || p.name.toLowerCase().includes(needle)
      || p.command.toLowerCase().includes(needle)
      || String(p.pid) === needle || p.user.toLowerCase().includes(needle),
  );
  if (!items.length) return `<tr><td colspan="6">${ui.emptyState("No matching processes", "activity")}</td></tr>`;
  return items
    .map(
      (p) => `<tr>
      <td class="num mono">${p.pid}</td>
      <td><span class="row" style="gap:7px"><span class="badge" style="padding:2px 7px;font-size:10.5px">${esc(p.state)}</span>${esc(p.user)}</span></td>
      <td class="num mono" style="color:${p.cpu > 50 ? "var(--warn)" : "inherit"}">${p.cpu.toFixed(1)}%</td>
      <td class="num mono">${bytes(p.mem)}</td>
      <td><span class="ellipsis mono" title="${esc(p.command)}">${esc(p.name)}</span>
        <div class="faint ellipsis" style="font-size:11px">${esc(p.command)}</div></td>
      <td class="actions">
        <button class="icon-btn" data-detail="${p.pid}" title="Details" aria-label="Details">${icon("info")}</button>
        <button class="icon-btn" data-kill="${p.pid}" title="Send signal" aria-label="Kill"
          style="color:var(--danger)">${icon("power")}</button>
      </td>
    </tr>`,
    )
    .join("");
}

function portsRows() {
  if (!state.ports) return `<tr><td colspan="5">${ui.skeletonRows(3, 30)}</td></tr>`;
  if (!state.ports.length) return `<tr><td colspan="5">${ui.emptyState("No listening sockets", "network")}</td></tr>`;
  return state.ports
    .map(
      (p) => `<tr>
      <td><span class="badge" style="text-transform:uppercase">${esc(p.protocol)}</span></td>
      <td class="mono">${esc(p.address)}</td>
      <td class="num mono"><b>${p.port}</b></td>
      <td>${p.process ? `${esc(p.process)} <span class="faint mono">#${p.pid}</span>` : `<span class="faint">unknown</span>`}</td>
      <td class="faint mono">${esc(p.state)}</td>
    </tr>`,
    )
    .join("");
}

function table() {
  if (state.tab === "processes") {
    return `<div class="table-wrap"><table class="tbl">
      <thead><tr>
        <th class="num">PID</th><th>User / state</th><th class="num">CPU</th>
        <th class="num">Memory</th><th>Command</th><th class="no-sort"></th>
      </tr></thead>
      <tbody id="proc-body">${procRows()}</tbody>
    </table></div>`;
  }
  return `${state.portsNote ? `<div class="notice" style="margin-bottom:10px">${icon("info")}<div>${esc(state.portsNote)}</div></div>` : ""}
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>Proto</th><th>Address</th><th class="num">Port</th><th>Process</th><th>State</th></tr></thead>
      <tbody id="port-body">${portsRows()}</tbody>
    </table></div>`;
}

function shell() {
  return `<div class="view-enter">
    <div class="card">
      <div class="tabs" id="proc-tabs">
        <button class="tab ${state.tab === "processes" ? "active" : ""}" data-tab="processes">Processes</button>
        <button class="tab ${state.tab === "ports" ? "active" : ""}" data-tab="ports">Listening ports</button>
      </div>
      <div class="toolbar">
        <div class="search">${icon("search")}
          <input class="input" id="proc-filter" placeholder="Filter by name, pid, user or command"
                 value="${esc(state.filter)}" autocomplete="off">
        </div>
        ${state.tab === "processes" ? `
        <select class="select" id="proc-sort" style="max-width:160px;min-height:40px;padding:8px 36px 8px 12px">
          <option value="cpu" ${state.sort === "cpu" ? "selected" : ""}>Sort: CPU</option>
          <option value="mem" ${state.sort === "mem" ? "selected" : ""}>Sort: memory</option>
          <option value="pid" ${state.sort === "pid" ? "selected" : ""}>Sort: PID</option>
          <option value="name" ${state.sort === "name" ? "selected" : ""}>Sort: name</option>
        </select>` : ""}
        <button class="btn btn-sm" id="proc-refresh">${icon("refresh")}Refresh</button>
        <button class="btn btn-sm ${state.live ? "btn-primary" : ""}" id="proc-live">
          ${icon(state.live ? "pause" : "play")}${state.live ? "Live" : "Paused"}
        </button>
        <span class="faint right" style="font-size:12px" id="proc-summary"></span>
      </div>
      <div id="proc-table">${table()}</div>
    </div>
  </div>`;
}

async function refresh() {
  try {
    if (state.tab === "processes") {
      const data = await api.get("/api/system/processes", { limit: 500, sort: state.sort });
      state.items = data.items;
      const body = document.getElementById("proc-body");
      if (body) body.innerHTML = procRows();
      const summary = document.getElementById("proc-summary");
      if (summary) summary.textContent = `${data.total} processes · ${data.cpu_count} cores`;
    } else {
      const data = await api.get("/api/system/ports");
      state.ports = data.items;
      state.portsNote = data.note;
      const host = document.getElementById("proc-table");
      if (host) host.innerHTML = table();
    }
  } catch (err) {
    ui.showError(err, "Could not refresh");
  }
}

async function showDetail(pid) {
  let detail;
  try {
    detail = await api.get(`/api/system/process/${pid}`);
  } catch (err) {
    ui.showError(err, "Cannot inspect this process");
    return;
  }
  const content = `<dl class="kv">
    <dt>PID</dt><dd class="mono">${detail.pid}</dd>
    <dt>Parent PID</dt><dd class="mono">${detail.ppid}</dd>
    <dt>Name</dt><dd>${esc(detail.name)}</dd>
    <dt>State</dt><dd>${esc(detail.state)}</dd>
    <dt>User</dt><dd>${esc(detail.user || "—")}</dd>
    <dt>Threads</dt><dd>${detail.threads}</dd>
    <dt>Resident memory</dt><dd>${bytes(detail.rss)}</dd>
    <dt>Virtual memory</dt><dd>${bytes(detail.vsz)}</dd>
    <dt>Open FDs</dt><dd>${detail.open_fds ?? "—"}</dd>
    <dt>Working dir</dt><dd class="mono truncate">${esc(detail.cwd || "—")}</dd>
    <dt>Executable</dt><dd class="mono truncate">${esc(detail.exe || "—")}</dd>
  </dl>
  <div class="field" style="margin-top:14px">
    <label>Command line</label>
    <div class="code-out">${esc(detail.command || "(no command line)")}</div>
  </div>`;
  const s = ui.sheet({
    title: detail.name,
    subtitle: `pid ${detail.pid} · ${detail.user || "unknown user"}`,
    content,
    wide: true,
    actions: [
      { label: "SIGTERM (graceful)", danger: true, icon: "power",
        onClick: () => signalPid(detail.pid, "TERM") },
      { label: "SIGKILL (force)", danger: true, icon: "trash",
        onClick: () => signalPid(detail.pid, "KILL") },
      { label: "Close", kind: "ghost" },
    ],
  });
  return s;
}

async function signalPid(pid, signal) {
  const ok = await ui.confirmDialog({
    title: `Send SIG${signal}?`,
    message: `Process ${pid} will receive SIG${signal}. ${signal === "KILL" ? "This cannot be undone." : "The process may exit."}`,
    confirmLabel: `Send SIG${signal}`,
    danger: true,
  });
  if (!ok) return;
  try {
    const result = await api.post(`/api/system/process/${pid}/signal`, {}, { signal });
    ui.notifyOk("Signal sent", result.message);
    refresh();
  } catch (err) {
    ui.showError(err, "Signal failed");
  }
}

export default {
  title: "Processes",
  crumb: "real process table from /proc",
  async mount(container, ctx) {
    state.ctx = ctx;
    container.innerHTML = shell();
    await refresh();

    container.addEventListener("click", (event) => {
      const tab = event.target.closest("[data-tab]");
      if (tab) {
        state.tab = tab.dataset.tab;
        container.innerHTML = shell();
        refresh();
        return;
      }
      if (event.target.closest("#proc-refresh")) {
        refresh();
        return;
      }
      if (event.target.closest("#proc-live")) {
        state.live = !state.live;
        container.innerHTML = shell();
        if (state.live) startTimer();
        else stopTimer();
        refresh();
        return;
      }
      const detail = event.target.closest("[data-detail]");
      if (detail) {
        showDetail(Number(detail.dataset.detail));
        return;
      }
      const kill = event.target.closest("[data-kill]");
      if (kill) signalPid(Number(kill.dataset.kill), "TERM");
    });

    container.addEventListener("input", (event) => {
      if (event.target.id === "proc-filter") {
        state.filter = event.target.value;
        const body = document.getElementById("proc-body");
        if (body) body.innerHTML = procRows();
      }
    });
    container.addEventListener("change", (event) => {
      if (event.target.id === "proc-sort") {
        state.sort = event.target.value;
        refresh();
      }
    });

    function startTimer() {
      stopTimer();
      state.timer = setInterval(() => {
        if (!document.hidden && state.live) refresh();
      }, 3000);
    }
    function stopTimer() {
      if (state.timer) clearInterval(state.timer);
      state.timer = null;
    }
    this._start = startTimer;
    this._stop = stopTimer;
    if (state.live) startTimer();
  },
  unmount() {
    if (state.timer) clearInterval(state.timer);
    state.timer = null;
    state.ports = null;
  },
};
