/** SSH authorized_keys management for local users, subject to permissions. */
import { api } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc, copyText } from "../ui.js";

const state = { users: [], user: "", data: null, loading: false, isRoot: false };

function keyList() {
  if (!state.data) return ui.skeletonRows(2, 60);
  if (!state.data.keys.length) {
    return ui.emptyState("No authorized keys yet for this user", "key");
  }
  return `<div class="list">${state.data.keys
    .map(
      (k, i) => `<div class="list-row" style="cursor:default">
        <span class="lead">${icon("key")}</span>
        <span class="grow truncate">
          <span class="title truncate">${esc(k.type)} <span class="faint" style="font-size:11.5px">${esc(k.comment || "no comment")}</span></span>
          <span class="meta truncate"><span class="mono">${esc(k.fingerprint_hint)}</span></span>
        </span>
        <button class="icon-btn" data-copy="${esc(k.full)}" title="Copy key">${icon("copy")}</button>
        <button class="icon-btn" data-remove="${i}" title="Remove key" style="color:var(--danger)">${icon("trash")}</button>
      </div>`,
    )
    .join("")}</div>`;
}

function shell() {
  const d = state.data;
  return `<div class="view-enter">
    <div class="card">
      <div class="card-head">
        <div class="card-title-icon">${icon("key")}</div>
        <div><h3>SSH authorized keys</h3>
          <div class="sub">${d ? esc(d.path) : ""}</div></div>
        <div class="spacer"></div>
        <button class="btn btn-sm" id="ssh-refresh">${icon("refresh")}Refresh</button>
      </div>
      <div class="field" style="max-width:340px">
        <label>User</label>
        <select class="select" id="ssh-user">
          ${state.users
            .map((u) => `<option value="${esc(u.name)}" ${u.name === state.user ? "selected" : ""}>
              ${esc(u.name)} (uid ${u.uid})</option>`)
            .join("")}
        </select>
      </div>
      ${d && !d.writable
        ? `<div class="notice" style="margin-bottom:12px">${icon("lock")}<div>Writing to this user's
            <span class="mono">authorized_keys</span> requires the panel to run as that user or as root.</div></div>`
        : ""}
      <div id="ssh-keys">${keyList()}</div>
    </div>

    <div class="card" style="margin-top:16px">
      <div class="card-head">
        <div class="card-title-icon">${icon("plus")}</div>
        <div><h3>Add a public key</h3><div class="sub">paste the contents of an id_*.pub file</div></div>
      </div>
      <div class="field">
        <textarea class="textarea" id="ssh-key-input" spellcheck="false"
          placeholder="ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAA… user@example"></textarea>
      </div>
      <div class="row" style="gap:10px;flex-wrap:wrap">
        <button class="btn btn-primary" id="ssh-add">${icon("plus")}Authorize key</button>
        ${
          state.isRoot
            ? `<button class="btn" id="ssh-gen">${icon("key")}Generate ed25519 keypair</button>`
            : ""
        }
      </div>
      <div class="notice info" style="margin-top:14px">${icon("info")}
        <div>Only public keys are written. Private keys never leave the server, and generating a
        keypair requires root so the file ownership matches the target user.</div></div>
    </div>
  </div>`;
}

async function loadKeys(container) {
  const host = document.getElementById("ssh-keys");
  if (host) host.innerHTML = ui.skeletonRows(2, 60);
  try {
    state.data = await api.get("/api/ssh/keys", { user: state.user });
    if (host) host.innerHTML = keyList();
  } catch (err) {
    state.data = null;
    if (host) {
      host.innerHTML = `<div class="notice danger">${icon("alert")}<div>${esc(ui.errorText(err))}</div></div>`;
    }
  }
}

export default {
  title: "SSH keys",
  crumb: "authorized_keys management",
  async mount(container, ctx) {
    try {
      const data = await api.get("/api/system/users");
      state.users = data.users;
      state.isRoot = data.root;
      state.user = data.whoami && state.users.some((u) => u.name === data.whoami)
        ? data.whoami
        : (state.users[0]?.name || "root");
    } catch (err) {
      container.innerHTML = `<div class="card">${ui.emptyState(ui.errorText(err), "alert")}</div>`;
      return;
    }
    container.innerHTML = shell();
    await loadKeys(container);

    container.addEventListener("change", (event) => {
      if (event.target.id === "ssh-user") {
        state.user = event.target.value;
        loadKeys(container);
      }
    });

    container.addEventListener("click", async (event) => {
      if (event.target.closest("#ssh-refresh")) {
        loadKeys(container);
        return;
      }
      const copyBtn = event.target.closest("[data-copy]");
      if (copyBtn) {
        copyText(copyBtn.dataset.copy);
        return;
      }
      const removeBtn = event.target.closest("[data-remove]");
      if (removeBtn) {
        const idx = Number(removeBtn.dataset.remove);
        const ok = await ui.confirmDialog({
          title: "Remove this key?",
          message: "Anyone using this key will lose SSH access to the account.",
          confirmLabel: "Remove key",
          danger: true,
        });
        if (!ok) return;
        try {
          await api.del("/api/ssh/keys", { user: state.user, index: idx });
          ui.notifyOk("Key removed", state.user);
          loadKeys(container);
        } catch (err) {
          ui.showError(err, "Could not remove the key");
        }
        return;
      }
      if (event.target.closest("#ssh-add")) {
        const area = document.getElementById("ssh-key-input");
        const key = area.value.trim();
        if (!key) {
          ui.notifyWarn("Nothing to add", "Paste a public key first.");
          return;
        }
        try {
          await api.post("/api/ssh/keys", { user: state.user, key });
          area.value = "";
          ui.notifyOk("Key authorized", state.user);
          loadKeys(container);
        } catch (err) {
          ui.showError(err, "Could not authorize the key");
        }
        return;
      }
      if (event.target.closest("#ssh-gen")) {
        try {
          const result = await api.post("/api/ssh/keygen", {}, { user: state.user });
          ui.sheet({
            title: "Keypair generated",
            subtitle: result.private_key_path,
            content: `<div class="field"><label>Public key</label>
              <div class="code-out">${esc(result.public_key)}</div></div>
              <div class="notice info">${icon("info")}<div>The private key stays on the server.
              Authorize the public key above to use it for logins.</div></div>`,
            actions: [
              { label: "Copy public key", icon: "copy",
                onClick: () => copyText(result.public_key), close: false },
              { label: "Close", kind: "primary" },
            ],
          });
        } catch (err) {
          ui.showError(err, "Could not generate a key");
        }
      }
    });
  },
  unmount() {},
};
