/** Thin API client with CSRF handling and structured errors. */

let csrfToken = null;
export const state = { csrf: null };

export class ApiError extends Error {
  constructor(message, status, detail) {
    super(message);
    this.status = status;
    this.detail = detail;
  }
}

export function setCsrf(token) {
  csrfToken = token || null;
  state.csrf = token || null;
}

export function getCsrf() {
  return csrfToken;
}

function emit(name, detail) {
  window.dispatchEvent(new CustomEvent(name, { detail }));
}

function buildUrl(path, query) {
  if (!query) return path;
  const params = new URLSearchParams();
  Object.entries(query).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== "") params.append(k, v);
  });
  const qs = params.toString();
  return qs ? `${path}?${qs}` : path;
}

async function request(method, path, { body, query, headers = {}, raw = false } = {}) {
  const opts = {
    method,
    credentials: "same-origin",
    headers: { Accept: "application/json", ...headers },
  };
  if (csrfToken && method !== "GET") opts.headers["X-PRIME-CSRF"] = csrfToken;
  if (body !== undefined) {
    if (raw) {
      opts.body = body;
    } else {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(body);
    }
  }
  let res;
  try {
    res = await fetch(buildUrl(path, query), opts);
  } catch (err) {
    throw new ApiError("Cannot reach the server. Check your connection.", 0, String(err));
  }
  if (res.status === 401) {
    emit("prime:unauthorized");
    throw new ApiError("Your session expired. Sign in again.", 401);
  }
  const type = res.headers.get("content-type") || "";
  const payload = type.includes("application/json") ? await res.json().catch(() => null) : null;
  if (!res.ok) {
    const detail = payload?.detail;
    const message = typeof detail === "string"
      ? detail
      : Array.isArray(detail)
        ? detail.map((d) => d.msg || JSON.stringify(d)).join("; ")
        : `Request failed (${res.status})`;
    throw new ApiError(message, res.status, detail);
  }
  return payload;
}

export const api = {
  get: (path, query) => request("GET", path, { query }),
  post: (path, body, query) => request("POST", path, { body: body ?? {}, query }),
  del: (path, query) => request("DELETE", path, { query }),
  /** Raw-body upload with progress; uses XHR because fetch has no upload progress. */
  upload(path, file, { onProgress } = {}) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", path, true);
      xhr.withCredentials = true;
      xhr.setRequestHeader("Content-Type", "application/octet-stream");
      if (csrfToken) xhr.setRequestHeader("X-PRIME-CSRF", csrfToken);
      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable && onProgress) onProgress(event.loaded / event.total);
      };
      xhr.onload = () => {
        let payload = null;
        try {
          payload = JSON.parse(xhr.responseText);
        } catch {
          payload = null;
        }
        if (xhr.status >= 200 && xhr.status < 300) resolve(payload);
        else reject(new ApiError(payload?.detail || `Upload failed (${xhr.status})`, xhr.status));
      };
      xhr.onerror = () => reject(new ApiError("Upload failed: network error", 0));
      xhr.onabort = () => reject(new ApiError("Upload cancelled", 0));
      xhr.send(file);
    });
  },
};

export async function downloadFile(path, query) {
  const res = await fetch(buildUrl(path, query), { credentials: "same-origin" });
  if (!res.ok) {
    let message = `Download failed (${res.status})`;
    try {
      const data = await res.json();
      if (data?.detail) message = data.detail;
    } catch { /* ignore */ }
    throw new ApiError(message, res.status);
  }
  const blob = await res.blob();
  const disposition = res.headers.get("content-disposition") || "";
  let filename = "download";
  const match = /filename\*=UTF-8''([^;]+)/i.exec(disposition);
  if (match) filename = decodeURIComponent(match[1]);
  else if (/filename="?([^";]+)"?/i.test(disposition)) {
    filename = /filename="?([^";]+)"?/i.exec(disposition)[1];
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  return filename;
}
