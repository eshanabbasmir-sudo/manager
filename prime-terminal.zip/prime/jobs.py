"""Background job runner used for package operations, service actions and
long-running diagnostics. Output is captured (bounded) and can be polled by
the UI, so a slow ``apt install`` never blocks an HTTP request.
"""
from __future__ import annotations

import asyncio
import os
import shlex
import shutil
import time
import uuid
from dataclasses import dataclass, field
from typing import Optional

MAX_OUTPUT = 256 * 1024


@dataclass
class Job:
    id: str
    label: str
    command: list[str]
    started: float = field(default_factory=time.time)
    finished: Optional[float] = None
    exit_code: Optional[int] = None
    output: str = ""
    running: bool = True
    error: str = ""
    needs_root: bool = False

    def public(self) -> dict:
        return {
            "id": self.id,
            "label": self.label,
            "command": " ".join(shlex.quote(c) for c in self.command),
            "started": self.started,
            "finished": self.finished,
            "exit_code": self.exit_code,
            "output": self.output,
            "running": self.running,
            "error": self.error,
        }


class JobManager:
    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self.jobs: dict[str, Job] = {}
        self._procs: dict[str, asyncio.subprocess.Process] = {}

    def _trim(self) -> None:
        if len(self.jobs) > 60:
            done = sorted((j for j in self.jobs.values() if not j.running),
                          key=lambda j: j.started)
            for job in done[:len(self.jobs) - 60]:
                self.jobs.pop(job.id, None)

    def _privilege(self, argv: list[str]) -> tuple[list[str], bool]:
        """Prefix with sudo -n when we are not root and sudo exists."""
        if os.geteuid() == 0:
            return argv, False
        sudo = shutil.which("sudo")
        if sudo:
            return [sudo, "-n"] + argv, True
        return argv, True

    async def start(self, label: str, argv: list[str], env: dict | None = None,
                    cwd: str | None = None, use_sudo: bool = False) -> Job:
        needs_root = False
        if use_sudo:
            argv, needs_root = self._privilege(argv)
        job = Job(id=uuid.uuid4().hex[:12], label=label, command=argv, needs_root=needs_root)
        self.jobs[job.id] = job
        self._trim()
        asyncio.create_task(self._run(job, env, cwd))
        return job

    async def _run(self, job: Job, env: dict | None, cwd: str | None) -> None:
        full_env = dict(os.environ)
        full_env.update({
            "DEBIAN_FRONTEND": "noninteractive",
            "LC_ALL": "C.UTF-8",
            "TERM": "dumb",
            "NO_COLOR": "1",
        })
        if env:
            full_env.update(env)
        try:
            proc = await asyncio.create_subprocess_exec(
                *job.command, stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT, stdin=asyncio.subprocess.DEVNULL,
                env=full_env, cwd=cwd)
        except (FileNotFoundError, PermissionError, OSError) as exc:
            job.running = False
            job.finished = time.time()
            job.exit_code = 127
            job.error = f"could not start command: {exc}"
            job.output = job.error + "\n"
            return
        self._procs[job.id] = proc
        chunks: list[str] = []
        size = 0
        assert proc.stdout is not None
        try:
            while True:
                line = await proc.stdout.readline()
                if not line:
                    break
                text = line.decode("utf-8", "replace")
                if size < MAX_OUTPUT:
                    chunks.append(text)
                    size += len(text)
                job.output = "".join(chunks)
        except asyncio.CancelledError:
            proc.kill()
            raise
        finally:
            code = await proc.wait()
            job.exit_code = code
            job.running = False
            job.finished = time.time()
            if size >= MAX_OUTPUT:
                job.output += "\n[output truncated]\n"
            job.output = job.output[-MAX_OUTPUT:]
            self._procs.pop(job.id, None)

    async def cancel(self, job_id: str) -> bool:
        proc = self._procs.get(job_id)
        if not proc:
            return False
        try:
            proc.terminate()
            await asyncio.sleep(1)
            if proc.returncode is None:
                proc.kill()
        except ProcessLookupError:
            pass
        return True

    def get(self, job_id: str) -> Optional[Job]:
        return self.jobs.get(job_id)

    def list(self) -> list[dict]:
        return [j.public() for j in sorted(self.jobs.values(), key=lambda j: -j.started)][:30]
