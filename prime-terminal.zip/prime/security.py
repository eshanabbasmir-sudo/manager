"""Password hashing, tokens, rate limiting and filesystem path validation."""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import re
import secrets
import time
from typing import Iterable

# ---------------------------------------------------------------------------
# Password hashing (scrypt from the standard library, no external deps)
# ---------------------------------------------------------------------------
SCRYPT_N = 2 ** 15
SCRYPT_R = 8
SCRYPT_P = 1
SCRYPT_LEN = 32
SCRYPT_MAXMEM = 128 * 1024 * 1024


def hash_password(password: str) -> str:
    if not isinstance(password, str) or len(password) < 8:
        raise ValueError("password must be at least 8 characters")
    salt = secrets.token_bytes(16)
    dk = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=SCRYPT_N, r=SCRYPT_R,
                        p=SCRYPT_P, dklen=SCRYPT_LEN, maxmem=SCRYPT_MAXMEM)
    return "scrypt${}${}${}${}${}".format(
        SCRYPT_N, SCRYPT_R, SCRYPT_P,
        base64.b64encode(salt).decode(), base64.b64encode(dk).decode())


def verify_password(password: str, stored: str) -> bool:
    """Constant-time-ish verification. Always costs a scrypt round on failure."""
    try:
        algo, n, r, p, salt_b64, hash_b64 = stored.split("$")
        if algo != "scrypt":
            return False
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(hash_b64)
        dk = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=int(n), r=int(r),
                            p=int(p), dklen=len(expected), maxmem=SCRYPT_MAXMEM)
        return hmac.compare_digest(dk, expected)
    except (ValueError, TypeError):
        return False


DUMMY_HASH = hash_password(secrets.token_urlsafe(24))


def password_problems(password: str) -> list[str]:
    problems = []
    if len(password) < 10:
        problems.append("Use at least 10 characters.")
    if not re.search(r"[A-Za-z]", password):
        problems.append("Include at least one letter.")
    if not re.search(r"\d", password):
        problems.append("Include at least one digit.")
    if password.lower() in {"password", "prime", "admin", "changeme", "12345678"}:
        problems.append("That password is too common.")
    return problems


# ---------------------------------------------------------------------------
# Tokens
# ---------------------------------------------------------------------------
def new_token(nbytes: int = 32) -> str:
    return secrets.token_urlsafe(nbytes)


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def constant_eq(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode("utf-8", "replace"), b.encode("utf-8", "replace"))


# ---------------------------------------------------------------------------
# Login rate limiting (in-memory, per (ip, username) and per ip)
# ---------------------------------------------------------------------------
class RateLimiter:
    def __init__(self, max_failures: int = 5, base: int = 60, cap: int = 900) -> None:
        self.max_failures = max_failures
        self.base = base
        self.cap = cap
        self._state: dict[str, dict[str, float]] = {}

    def _entry(self, key: str) -> dict[str, float]:
        now = time.time()
        ent = self._state.get(key)
        if ent is None:
            ent = self._state[key] = {"fails": 0, "until": 0.0, "seen": now}
        ent["seen"] = now
        return ent

    def retry_after(self, key: str) -> int:
        ent = self._entry(key)
        remaining = ent["until"] - time.time()
        return max(0, int(remaining + 0.999))

    def register_failure(self, key: str) -> int:
        ent = self._entry(key)
        ent["fails"] += 1
        if ent["fails"] >= self.max_failures:
            over = ent["fails"] - self.max_failures
            delay = min(self.cap, self.base * (2 ** over))
            ent["until"] = time.time() + delay
            return delay
        return 0

    def reset(self, key: str) -> None:
        self._state.pop(key, None)

    def sweep(self, older_than: float = 86400) -> None:
        cutoff = time.time() - older_than
        for key in [k for k, v in self._state.items() if v["seen"] < cutoff and v["until"] < cutoff]:
            self._state.pop(key, None)


# ---------------------------------------------------------------------------
# Filesystem path safety
# ---------------------------------------------------------------------------
class PathError(ValueError):
    """Raised when a requested path escapes the configured roots."""


def _within(path: str, root: str) -> bool:
    if root == "/":
        return True
    return path == root or path.startswith(root.rstrip("/") + "/")


def safe_path(requested: str, roots: Iterable[str], must_exist: bool = False) -> str:
    """Resolve *requested* to an absolute real path inside one of *roots*.

    Symlinks are resolved before the check, so ``/allowed/link-to-/etc`` is
    rejected. Non-existent leaves are resolved through their nearest existing
    parent so that creating new files is still safe.
    """
    if requested in ("", None):
        requested = "/"
    if "\x00" in requested:
        raise PathError("invalid path")
    if not requested.startswith("/"):
        raise PathError("path must be absolute")
    if ".." in requested.split("/"):
        # normalise first; a literal '..' segment is fine only if it stays inside
        requested = os.path.normpath(requested)

    roots = [os.path.realpath(r) for r in roots]
    real = os.path.realpath(requested)
    if not _within(real, max(roots, key=len)) and not any(_within(real, r) for r in roots):
        raise PathError("path is outside the allowed roots")

    if must_exist and not os.path.exists(real):
        raise PathError("path does not exist")

    # resolve symlink chains for non-existent tails
    if not os.path.exists(real):
        parent = os.path.dirname(real)
        seen = 0
        while parent and parent != "/" and not os.path.exists(parent) and seen < 64:
            parent = os.path.dirname(parent)
            seen += 1
        real_parent = os.path.realpath(parent)
        if not any(_within(real_parent, r) for r in roots):
            raise PathError("parent directory is outside the allowed roots")
    return real


def is_protected(path: str, protected: Iterable[str]) -> bool:
    real = os.path.realpath(path)
    return real in {os.path.realpath(p) for p in protected}


SAFE_NAME_RE = re.compile(r"^[^/\x00]{1,255}$")


def safe_child_name(name: str) -> str:
    if not isinstance(name, str) or not SAFE_NAME_RE.match(name):
        raise PathError("invalid file name")
    if name in (".", ".."):
        raise PathError("invalid file name")
    return name


def safe_filename_for_upload(name: str) -> str:
    base = os.path.basename(name.replace("\\", "/"))
    base = re.sub(r"[\x00-\x1f]", "", base).strip()
    if base in ("", ".", ".."):
        raise PathError("invalid upload file name")
    return base[:255]


def shell_quote(value: str) -> str:
    return "'" + value.replace("'", "'\\''") + "'"


PKG_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+:~\-]{0,190}$")


def valid_package_name(name: str) -> bool:
    return bool(PKG_NAME_RE.match(name or ""))

SERVICE_NAME_RE = re.compile(r"^[A-Za-z0-9@._:\\\-]{1,128}$")


def valid_service_name(name: str) -> bool:
    return bool(SERVICE_NAME_RE.match(name or ""))


SSH_KEY_RE = re.compile(
    r"^(ssh-(rsa|dss|ed25519)|ecdsa-sha2-nistp(256|384|521)|sk-(ssh-ed25519|ecdsa-sha2-nistp256)@openssh\.com)"
    r"\s+AAAA[A-Za-z0-9+/=]{20,}\s*(.*)$")


def valid_ssh_key(line: str) -> bool:
    return bool(SSH_KEY_RE.match((line or "").strip()))
