"""Shared runtime objects and FastAPI dependencies."""
from __future__ import annotations

import time
from typing import Optional

from fastapi import HTTPException, Request

from .auth import Session
from .config import Config
from .jobs import JobManager
from .ops import OpError
from .ptyterm import TerminalManager
from .auth import AuthStore
from . import security


class Runtime:
    def __init__(self, cfg: Config) -> None:
        self.cfg = cfg
        self.started = time.time()
        self.auth = AuthStore(cfg)
        self.terms = TerminalManager(cfg)
        self.jobs = JobManager(cfg)
        self.limiter = security.RateLimiter(cfg.login_max_failures, cfg.login_lockout_base,
                                            cfg.login_lockout_max)
        self.version = "1.0.0"


def get_rt(request: Request) -> Runtime:
    return request.app.state.rt


SESSION_COOKIE = "prime_session"


def get_session(request: Request, required: bool = True) -> Optional[Session]:
    rt = get_rt(request)
    token = request.cookies.get(SESSION_COOKIE)
    session = rt.auth.lookup(token) if token else None
    if session is None and required:
        raise HTTPException(status_code=401, detail="authentication required")
    return session


def client_ip(request: Request) -> str:
    rt = get_rt(request)
    if rt.cfg.behind_proxy:
        fwd = request.headers.get("x-forwarded-for", "")
        if fwd:
            candidate = fwd.split(",")[0].strip()
            if candidate:
                return candidate
    return request.client.host if request.client else ""


def require_csrf(request: Request, session: Session) -> None:
    """Cookie-authenticated state changes must carry the per-session CSRF token."""
    header = request.headers.get("x-prime-csrf", "")
    if not header or not security.constant_eq(header, session.csrf):
        # Double-submit fallback: header must match the (non-HttpOnly) mirror cookie
        cookie = request.cookies.get("prime_csrf", "")
        if not (header and cookie and security.constant_eq(header, cookie)
                and security.constant_eq(cookie, session.csrf)):
            raise HTTPException(status_code=403, detail="invalid CSRF token")


def origin_ok(request: Request) -> bool:
    """Reject cross-site state-changing requests even without CSRF token reuse."""
    origin = request.headers.get("origin")
    if not origin:
        return True  # same-origin fetch from older clients may omit it
    host = request.headers.get("host", "")
    try:
        from urllib.parse import urlsplit
        o = urlsplit(origin)
        return o.netloc == host
    except ValueError:
        return False
