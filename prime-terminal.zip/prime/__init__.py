"""PRIME TERMINAL — a real Linux control panel.

The package is intentionally dependency-light: FastAPI + uvicorn + the Python
standard library. Everything that talks to the operating system (processes,
CPU, memory, disks, network, PTYs) uses /proc, /sys and POSIX syscalls
directly, so the numbers shown in the UI are always the kernel's own numbers.
"""

__version__ = "1.0.0"
APP_NAME = "PRIME TERMINAL"
